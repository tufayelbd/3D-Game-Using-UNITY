﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreScense : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}

    public void scorSec() {

 
    
    }
	// Update is called once per frame
	void Update () {
		
	}
}
