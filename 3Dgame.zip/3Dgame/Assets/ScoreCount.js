﻿static var gscore :int=0; 
static var count: int=0;
function OnGUI(){
	GUI.Button(Rect(100,50,100,20),("Score : "+gscore));
//	GUI.Button(Rect(100,100,100,20),("Score : "+count));

}